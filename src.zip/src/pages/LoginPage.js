import { View, Text } from 'react-native'

const LoginPage = () => {
  return (
    <View>
      <Text>LoginPagesakdhakjsdhaskjdhkjsa</Text>
    </View>
  )
}
export default LoginPage